// src/components/Header.tsx
import { useEffect, useMemo, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Menu,
  X,
  MapPin,
  Phone,
  Mail,
  ChevronDown,
  GraduationCap,
  ShieldCheck,
} from "lucide-react";
import logo from "@/assets/logo.png";
import LoginModal from "./LoginModal"; // ⬅️ nuevo

/**
 * Config rápido de la institución
 * Ajusta aquí y se reflejará en todo el header.
 */
const INSTITUCION = {
  nombreCorto: "UEP Técnico Humanístico",
  nombreLargo: "Unidad Educativa Privada Técnico Humanístico Ebenezer",
  telefono: " +591 65317080",
  email: "LuisFredy@uepth.edu",
  direccion: "Av. Educación 123, bolivia",
};

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [elevated, setElevated] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false); // ⬅️ nuevo
  const location = useLocation();

  // Enlaces de navegación (para escritorio y móvil)
  const navLinks = useMemo(
    () => [
      { label: "Nosotros", hash: "#about" },
      { label: "Admisiones", hash: "#admisiones" },
      { label: "Noticias", hash: "#noticias" },
      { label: "Contacto", hash: "#contact" },
    ],
    []
  );

  const isActiveHash = (hash: string) => location.hash === hash;

  // Scroll suave
  useEffect(() => {
    document.documentElement.style.scrollBehavior = "smooth";
  }, []);

  // Sombra y fondo blur al hacer scroll
  useEffect(() => {
    const onScroll = () => setElevated(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Cierra menú móvil al cambiar de ruta o hash
  useEffect(() => {
    setIsMenuOpen(false);
  }, [location.pathname, location.hash]);

  // Accesibilidad: cerrar con ESC (menú + modal)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setIsMenuOpen(false);
        setIsLoginModalOpen(false); // ⬅️ nuevo
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // Cerrar el menú móvil si se vuelve a tamaño de escritorio
  useEffect(() => {
    const onResize = () => {
      if (window.innerWidth >= 768) setIsMenuOpen(false);
    };
    window.addEventListener("resize", onResize, { passive: true });
    return () => window.removeEventListener("resize", onResize);
  }, []);

  // Abrir/cerrar modal
  const openLoginModal = () => {
    setIsLoginModalOpen(true);
    setIsMenuOpen(false);
  };
  const closeLoginModal = () => setIsLoginModalOpen(false);

  return (
    <>
      <header
        className={[
          "w-full sticky top-0 z-40 transition-all",
          elevated ? "backdrop-blur bg-background/75 border-b shadow-sm" : "bg-background",
        ].join(" ")}
        aria-label="Barra de navegación principal"
      >
        {/* Enlace de salto para accesibilidad */}
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-50 focus:bg-primary focus:text-primary-foreground focus:px-3 focus:py-2 focus:rounded-md"
        >
          Saltar al contenido
        </a>

        {/* Top bar de contacto */}
        <div className="w-full bg-muted/50 border-b">
          <div className="container mx-auto px-4 py-2 text-xs md:text-sm text-muted-foreground">
            <div className="flex flex-wrap items-center gap-3 justify-between">
              <div className="flex flex-wrap items-center gap-4">
                <span className="inline-flex items-center gap-1">
                  <MapPin className="h-3.5 w-3.5" />
                  {INSTITUCION.direccion}
                </span>
                <a
                  href={`tel:${INSTITUCION.telefono.replace(/\s+/g, "")}`}
                  className="inline-flex items-center gap-1 hover:text-foreground"
                  title="Llamar"
                >
                  <Phone className="h-3.5 w-3.5" />
                  {INSTITUCION.telefono}
                </a>
                <a
                  href={`mailto:${INSTITUCION.email}`}
                  className="inline-flex items-center gap-1 hover:text-foreground"
                  title="Enviar correo"
                >
                  <Mail className="h-3.5 w-3.5" />
                  {INSTITUCION.email}
                </a>
              </div>
              <div className="hidden md:flex items-center gap-2">
                <span className="inline-flex items-center gap-1 text-emerald-700">
                  <ShieldCheck className="h-4 w-4" /> Plataforma segura
                </span>
                <span className="hidden sm:inline">•</span>
                <span className="inline-flex items-center gap-1 text-sky-700">
                  <GraduationCap className="h-4 w-4" /> Enfoque técnico humanístico
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Barra principal */}
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            {/* Logo + marca */}
            <Link to="/" className="flex items-center gap-3 group" aria-label="Ir al inicio">
              <img
                src={logo}
                alt={`${INSTITUCION.nombreCorto} - Logo`}
                className="h-12 w-auto object-contain transition-transform group-hover:scale-[1.02]"
              />
              <div className="hidden md:block">
                <h1 className="text-lg font-bold leading-tight">
                  {INSTITUCION.nombreCorto}
                </h1>
                <p className="text-xs text-muted-foreground leading-none">
                  {INSTITUCION.nombreLargo}
                </p>
              </div>
            </Link>

            {/* Navegación escritorio */}
            <nav className="hidden md:flex items-center gap-1" role="navigation" aria-label="Navegación del sitio">
              {/* Nosotros */}
              <a href="#about" aria-current={isActiveHash("#about") ? "page" : undefined}>
                <Button
                  variant="ghost"
                  className={`hover:text-foreground ${
                    isActiveHash("#about") ? "text-foreground" : "text-muted-foreground"
                  }`}
                >
                  Nosotros
                </Button>
              </a>

              {/* Niveles */}
              <div className="relative group">
                <Button
                  variant="ghost"
                  className="hover:text-foreground text-muted-foreground inline-flex items-center"
                  aria-haspopup="menu"
                  aria-expanded="false"
                >
                  Niveles <ChevronDown className="ml-1 h-4 w-4" />
                </Button>
                <div className="absolute left-0 mt-2 hidden group-hover:block">
                  <Card className="p-2 w-52" role="menu" aria-label="Niveles educativos">
                    <a href="#nivel-inicial" className="block px-3 py-2 rounded-md hover:bg-muted">
                      Inicial
                    </a>
                    <a href="#nivel-primaria" className="block px-3 py-2 rounded-md hover:bg-muted">
                      Primaria
                    </a>
                    <a href="#nivel-secundaria" className="block px-3 py-2 rounded-md hover:bg-muted">
                      Secundaria
                    </a>
                  </Card>
                </div>
              </div>

              {/* Resto de enlaces */}
              {navLinks
                .filter((l) => l.hash !== "#about")
                .map((l) => (
                  <a key={l.hash} href={l.hash} aria-current={isActiveHash(l.hash) ? "page" : undefined}>
                    <Button
                      variant="ghost"
                      className={`hover:text-foreground ${
                        isActiveHash(l.hash) ? "text-foreground" : "text-muted-foreground"
                      }`}
                    >
                      {l.label}
                    </Button>
                  </a>
                ))}
            </nav>

            {/* CTAs */}
            <div className="hidden md:flex items-center gap-2">
              {/* Nueva opción: abrir modal */}
              <Button variant="academicOutline" onClick={openLoginModal}>
                Ingresar
              </Button>

              {/* Fallback opcional: enlace original (oculto) */}
              <Link to="/#login" className="hidden">
                <Button variant="academicOutline">Ingresar (Link)</Button>
              </Link>

              <a href="#admisiones">
                <Button variant="academic">Matrícula en línea</Button>
              </a>
            </div>

            {/* Botón móvil */}
            <button
              onClick={() => setIsMenuOpen((v) => !v)}
              className="md:hidden p-2 text-foreground hover:bg-muted rounded-md"
              aria-label="Abrir menú"
              aria-expanded={isMenuOpen}
              aria-controls="mobile-menu"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>

          {/* Menú móvil */}
          {isMenuOpen && (
            <Card id="mobile-menu" className="mt-3 md:hidden p-3 bg-card border">
              <nav className="flex flex-col divide-y" role="navigation" aria-label="Navegación móvil">
                <a href="#about" className="py-3">
                  Nosotros
                </a>
                <div className="py-3">
                  <p className="text-sm font-medium mb-2 text-muted-foreground">Niveles</p>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                    <a href="#nivel-inicial" className="px-3 py-2 rounded-md bg-muted hover:bg-muted/80">
                      Inicial
                    </a>
                    <a href="#nivel-primaria" className="px-3 py-2 rounded-md bg-muted hover:bg-muted/80">
                      Primaria
                    </a>
                    <a href="#nivel-secundaria" className="px-3 py-2 rounded-md bg-muted hover:bg-muted/80">
                      Secundaria
                    </a>
                  </div>
                </div>
                {navLinks
                  .filter((l) => l.hash !== "#about")
                  .map((l) => (
                    <a key={l.hash} href={l.hash} className="py-3">
                      {l.label}
                    </a>
                  ))}

                <div className="pt-3 flex gap-2">
                  {/* Nueva opción: abrir modal */}
                  <Button variant="academicOutline" className="w-full" onClick={openLoginModal}>
                    Ingresar
                  </Button>

                  {/* Fallback opcional: enlace original (oculto) */}
                  <Link to="/#login" className="flex-1 hidden">
                    <Button variant="academicOutline" className="w-full">
                      Ingresar (Link)
                    </Button>
                  </Link>

                  <a href="#admisiones" className="flex-1">
                    <Button variant="academic" className="w-full">
                      Matrícula
                    </Button>
                  </a>
                </div>
              </nav>
            </Card>
          )}
        </div>
      </header>

      {/* Modal de Login */}
      <LoginModal isOpen={isLoginModalOpen} onClose={closeLoginModal} />
    </>
  );
};

export default Header;
