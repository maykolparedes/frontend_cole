
// src/pages/parent/Asistencia.tsx
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Download, FileText, MessageSquare, Check, X } from 'lucide-react';

export default function Asistencia() {
  const asistencias = [
    { id: 1, fecha: '2025-03-02', curso: 'Cloud Computing', estado: 'Falta', justificada: false },
    { id: 2, fecha: '2025-03-05', curso: 'Calidad de Software', estado: 'Tarde', justificada: true },
    { id: 3, fecha: '2025-03-10', curso: 'Cloud Computing', estado: 'Asistió', justificada: true },
  ];

  const justificar = (id: number) => alert(`Enviar justificación para registro #${id}`);
  const verDetalle = (id: number) => alert(`Ver detalle de asistencia #${id}`);
  const contactar = () => alert('Abrir chat con tutor / coordinación.');

  return (
    <div className="space-y-4">
      {/* Acciones de Asistencia */}
      <div className="flex flex-wrap items-center gap-2">
        <Button variant="outline" size="sm" onClick={() => alert('Exportando asistencia a PDF…')}>
          <Download className="h-4 w-4 mr-2" /> Exportar PDF
        </Button>
        <Button variant="outline" size="sm" onClick={() => alert('Descargando reporte mensual…')}>
          <FileText className="h-4 w-4 mr-2" /> Reporte mensual
        </Button>
        <Button variant="outline" size="sm" onClick={contactar}>
          <MessageSquare className="h-4 w-4 mr-2" /> Mensaje al tutor
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Historial de Asistencia</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Fecha</TableHead>
                <TableHead>Curso</TableHead>
                <TableHead>Estado</TableHead>
                <TableHead>Justificación</TableHead>
                <TableHead>Acciones</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {asistencias.map(a => (
                <TableRow key={a.id}>
                  <TableCell>{a.fecha}</TableCell>
                  <TableCell>{a.curso}</TableCell>
                  <TableCell>{a.estado}</TableCell>
                  <TableCell className="flex items-center gap-2">
                    {a.justificada ? (
                      <>
                        <Check className="h-4 w-4" /> Justificada
                      </>
                    ) : (
                      <>
                        <X className="h-4 w-4" /> Sin justificar
                      </>
                    )}
                  </TableCell>
                  <TableCell className="space-x-2">
                    <Button size="sm" variant="secondary" onClick={() => verDetalle(a.id)}>Detalle</Button>
                    {!a.justificada && (
                      <Button size="sm" onClick={() => justificar(a.id)}>Justificar</Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
