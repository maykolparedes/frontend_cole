// src/pages/parent/Progreso.tsx
import React, { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  LineChart, // Para el progreso general
  BookOpen,
  CheckCircle,
  AlertCircle,
  Clock,
  LayoutDashboard, // Para el título principal
  TrendingUp, // Podría usarse para hitos o un progreso más dinámico
  Users, // Para docentes en materias
  Info // Para popovers o tooltips
} from 'lucide-react';
import { Separator } from '@/components/ui/separator'; // Para dividir secciones visualmente
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';


// Definiciones de tipos (reutilizadas de Tareas.tsx, puedes moverlas a un archivo común si hay muchos componentes que las comparten)
interface Tarea {
  id: number;
  titulo: string;
  materia: string;
  docente: string;
  fechaAsignacion: string; // Formato 'YYYY-MM-DD'
  fechaEntrega: string;     // Formato 'YYYY-MM-DD'
  estado: 'pendiente' | 'completado' | 'atrasado';
  prioridad: 'alta' | 'media' | 'baja';
  descripcion: string;
  archivosAdjuntos?: number;
  progreso?: number; // 0-100 para tareas pendientes
  calificacion?: number; // 0-100 para tareas completadas
}

interface Materia {
  id: number;
  nombre: string;
  docente: string;
  color: string; // Clases de Tailwind para el color del badge de materia
}

export default function Progreso() {

  // Datos de ejemplo (reutilizados de Tareas.tsx)
  const materias: Materia[] = useMemo(() => [
    { id: 1, nombre: 'Matemáticas', docente: 'Prof. García', color: 'bg-indigo-100 text-indigo-800' },
    { id: 2, nombre: 'Español', docente: 'Prof. López', color: 'bg-blue-100 text-blue-800' },
    { id: 3, nombre: 'Ciencias', docente: 'Prof. Martín', color: 'bg-emerald-100 text-emerald-800' },
    { id: 4, nombre: 'Historia', docente: 'Prof. Rodríguez', color: 'bg-purple-100 text-purple-800' },
    { id: 5, nombre: 'Inglés', docente: 'Prof. Smith', color: 'bg-yellow-100 text-yellow-800' }
  ], []);

  const tareas: Tarea[] = useMemo(() => [
    {
      id: 1,
      titulo: 'Ejercicios de álgebra',
      materia: 'Matemáticas',
      docente: 'Prof. García',
      fechaAsignacion: '2024-01-15',
      fechaEntrega: '2024-01-20',
      estado: 'completado', // Cambiado a completado para simular progreso
      prioridad: 'alta',
      descripcion: 'Resolver los ejercicios de la página 45 a 48 del libro de texto. Incluir procedimiento completo y mostrar los pasos detallados para cada solución. Presentar en formato PDF.',
      archivosAdjuntos: 2,
      progreso: 100,
      calificacion: 85
    },
    {
      id: 2,
      titulo: 'Ensayo sobre literatura contemporánea',
      materia: 'Español',
      docente: 'Prof. López',
      fechaAsignacion: '2024-01-10',
      fechaEntrega: '2024-01-18',
      estado: 'completado',
      prioridad: 'media',
      descripcion: 'Escribir un ensayo de 1000 palabras sobre la influencia de la literatura contemporánea en la sociedad actual. Incluir al menos 3 fuentes bibliográficas.',
      calificacion: 95
    },
    {
      id: 3,
      titulo: 'Proyecto del sistema solar',
      materia: 'Ciencias',
      docente: 'Prof. Martín',
      fechaAsignacion: '2024-01-05',
      fechaEntrega: '2024-01-25',
      estado: 'pendiente',
      prioridad: 'media',
      descripcion: 'Crear una maqueta del sistema solar incluyendo todos los planetas y sus características principales. Se valorará la creatividad y la precisión científica.',
      archivosAdjuntos: 1,
      progreso: 30
    },
    {
      id: 4,
      titulo: 'Investigación sobre la revolución industrial',
      materia: 'Historia',
      docente: 'Prof. Rodríguez',
      fechaAsignacion: '2024-01-08',
      fechaEntrega: '2024-01-12', // Esta fecha ya pasó
      estado: 'atrasado',
      prioridad: 'alta',
      descripcion: 'Investigar sobre las causas y consecuencias de la revolución industrial en Europa, con un enfoque en el impacto social y económico. Se requiere una bibliografía de 5 fuentes.',
      archivosAdjuntos: 3
    },
    {
      id: 5,
      titulo: 'Presentación sobre verbos irregulares',
      materia: 'Inglés',
      docente: 'Prof. Smith',
      fechaAsignacion: '2024-01-12',
      fechaEntrega: '2024-01-19',
      estado: 'pendiente',
      prioridad: 'baja',
      descripcion: 'Preparar una presentación sobre los verbos irregulares en inglés con ejemplos de uso y ejercicios interactivos para la clase.',
      progreso: 90
    },
    {
      id: 6,
      titulo: 'Problemas de física',
      materia: 'Ciencias',
      docente: 'Prof. Martín',
      fechaAsignacion: '2024-01-14',
      fechaEntrega: '2024-01-21',
      estado: 'completado', // Cambiado a completado
      prioridad: 'alta',
      descripcion: 'Resolver los problemas de física de las páginas 78-82 sobre cinemática. Mostrar todos los cálculos y unidades.',
      archivosAdjuntos: 1,
      progreso: 100,
      calificacion: 78
    },
    {
      id: 7,
      titulo: 'Lectura comprensiva: "Cien años de soledad"',
      materia: 'Español',
      docente: 'Prof. López',
      fechaAsignacion: '2024-01-01',
      fechaEntrega: '2024-01-10', // Esta fecha ya pasó
      estado: 'atrasado',
      prioridad: 'media',
      descripcion: 'Leer el libro "Cien años de soledad" y preparar un resumen crítico de los primeros 5 capítulos. Enfocarse en los personajes principales y el contexto histórico-literario.',
      archivosAdjuntos: 0 // Ejemplo sin adjuntos
    },
    {
      id: 8,
      titulo: 'Laboratorio de Química Inorgánica',
      materia: 'Ciencias',
      docente: 'Prof. Martín',
      fechaAsignacion: '2024-01-20',
      fechaEntrega: '2024-02-05',
      estado: 'pendiente',
      prioridad: 'alta',
      descripcion: 'Realizar el experimento de titulación ácido-base. Incluir reporte de materiales, procedimiento, resultados y conclusiones.',
      archivosAdjuntos: 0,
      progreso: 10
    }
  ], []);


  // CÁLCULOS PARA ESTADÍSTICAS Y PROGRESO GENERAL
  const generalProgress = useMemo(() => {
    // Calculamos un "progreso" basado en tareas completadas vs. total de tareas con calificación (o progreso si está pendiente)
    const totalConsideredTasks = tareas.length;
    if (totalConsideredTasks === 0) return 0;

    const completedTasksPoints = tareas.filter(t => t.estado === 'completado').length * 100;
    const pendingTasksProgressPoints = tareas
      .filter(t => t.estado === 'pendiente' && t.progreso !== undefined)
      .reduce((sum, task) => sum + (task.progreso || 0), 0);
    // Tareas atrasadas podrían contar como 0 o un puntaje negativo dependiendo de la lógica.
    // Por simplicidad, las atrasadas no contribuyen positivamente aquí, o se cuentan como 0 progreso.
    
    // Una forma simple: (Completadas * 100 + Progreso de pendientes) / Total de Tareas.
    // O si solo se consideran las completadas:
    const percentageCompleted = (tareas.filter(t => t.estado === 'completado').length / totalConsideredTasks) * 100;
    return Math.round(percentageCompleted);

    // O una media más compleja:
    // const totalScore = tareas.reduce((acc, tarea) => {
    //   if (tarea.estado === 'completado' && tarea.calificacion !== undefined) {
    //     return acc + tarea.calificacion; // Suma la calificación si está completada
    //   } else if (tarea.estado === 'pendiente' && tarea.progreso !== undefined) {
    //     return acc + tarea.progreso * 0.5; // O un porcentaje del progreso si aún no está calificada
    //   }
    //   return acc;
    // }, 0);
    // return Math.round(totalScore / totalConsideredTasks);

  }, [tareas]);

  // Progreso por materia
  const progressByMateria = useMemo(() => {
    return materias.map(materia => {
      const tareasMateria = tareas.filter(t => t.materia === materia.nombre);
      const completadas = tareasMateria.filter(t => t.estado === 'completado').length;
      const porcentaje = tareasMateria.length > 0 ? (completadas / tareasMateria.length) * 100 : 0;
      const pendientes = tareasMateria.filter(t => t.estado === 'pendiente').length;
      const atrasadas = tareasMateria.filter(t => t.estado === 'atrasado').length;
      const promedioCalificaciones = tareasMateria
        .filter(t => t.estado === 'completado' && t.calificacion !== undefined)
        .reduce((sum, t) => sum + (t.calificacion || 0), 0) / (completadas || 1); // Evitar división por cero

      return {
        ...materia,
        totalTareas: tareasMateria.length,
        completadas,
        pendientes,
        atrasadas,
        porcentaje: Math.round(porcentaje),
        promedioCalificaciones: Math.round(promedioCalificaciones)
      };
    });
  }, [tareas, materias]);

  // Tareas pendientes, las 3 próximas
  const upcomingPendingTasks = useMemo(() => {
    return tareas
      .filter(t => t.estado === 'pendiente')
      .sort((a, b) => new Date(a.fechaEntrega).getTime() - new Date(b.fechaEntrega).getTime())
      .slice(0, 3);
  }, [tareas]);

  const overdueTasksCount = useMemo(() => {
    return tareas.filter(t => t.estado === 'atrasado').length;
  }, [tareas]);

  const getProgressColor = (value: number) => {
    if (value < 30) return 'bg-red-500';
    if (value < 70) return 'bg-yellow-500';
    return 'bg-emerald-500';
  };

  return (
    <div className="space-y-8 p-4"> {/* Aumentado el padding y espaciado */}
      {/* Header */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground flex items-center gap-2">
            <LayoutDashboard className="h-7 w-7 text-academic-blue-500" />
            Tablero de Progreso Académico
          </h1>
          <p className="text-muted-foreground">
            Visualiza el avance general y por materia de Juan Pérez Martínez.
          </p>
        </div>
        <Button variant="outline" className="bg-academic-blue-500 hover:bg-academic-blue-600 text-white hover:text-white">
          <TrendingUp className="h-4 w-4 mr-2" />
          Ver Historial de Progreso
        </Button>
      </div>

      {/* Progreso General */}
      <Card className="shadow-lg">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-2xl font-bold">Progreso General</CardTitle>
          <LineChart className="h-6 w-6 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-5xl font-extrabold text-center py-4 text-academic-blue-500">
            {generalProgress}%
          </div>
          <Progress value={generalProgress} className="h-3 w-full" indicatorClassName={getProgressColor(generalProgress)} />
          <p className="text-sm text-muted-foreground text-center mt-2">
            Basado en tus tareas completadas y el avance de las pendientes.
          </p>
        </CardContent>
      </Card>

      {/* Resumen de Tareas Pendientes y Atrasadas */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-semibold">Próximas Tareas Pendientes</CardTitle>
            <Clock className="h-5 w-5 text-blue-500" />
          </CardHeader>
          <CardContent className="space-y-3">
            {upcomingPendingTasks.length > 0 ? (
              upcomingPendingTasks.map(tarea => (
                <div key={tarea.id} className="flex items-center justify-between border-b last:border-b-0 pb-2 last:pb-0">
                  <div>
                    <p className="font-medium">{tarea.titulo}</p>
                    <p className="text-sm text-muted-foreground flex items-center gap-1">
                      <BookOpen className="h-3 w-3" />
                      {tarea.materia} &bull; Entrega: {new Date(tarea.fechaEntrega).toLocaleDateString()}
                    </p>
                  </div>
                  <Badge variant="secondary" className="text-xs">
                    {tarea.progreso || 0}%
                  </Badge>
                </div>
              ))
            ) : (
              <p className="text-muted-foreground text-center py-4">No hay tareas pendientes próximas.</p>
            )}
            <Button variant="link" className="w-full text-academic-blue-500">Ver todas las tareas</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-lg font-semibold">
              Tareas Vencidas
              {overdueTasksCount > 0 && <Badge variant="destructive" className="ml-2 text-base">{overdueTasksCount}</Badge>}
            </CardTitle>
            <AlertCircle className="h-5 w-5 text-red-500" />
          </CardHeader>
          <CardContent>
            {overdueTasksCount > 0 ? (
              <p className="text-red-600 font-medium">
                ¡Tienes {overdueTasksCount} tarea{overdueTasksCount !== 1 ? 's' : ''} vencida{overdueTasksCount !== 1 ? 's' : ''}!
                Considera contactar a tus docentes.
              </p>
            ) : (
              <p className="text-muted-foreground text-center py-4">¡Excelente! No tienes tareas vencidas.</p>
            )}
            <Button variant="link" className="w-full text-academic-blue-500">Ir a Tareas Vencidas</Button>
          </CardContent>
        </Card>
      </div>


      <Separator className="my-8" /> {/* Separador visual */}

      {/* Progreso por Materia */}
      <h2 className="text-2xl font-bold text-foreground mb-4">Progreso por Materia</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {progressByMateria.map(materia => (
          <Card key={materia.id} className="group hover:shadow-md transition-shadow duration-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold flex items-center justify-between">
                <span className="flex items-center gap-2">
                  <BookOpen className="h-4 w-4 text-muted-foreground" />
                  {materia.nombre}
                </span>
                <Badge className={`px-2 py-1 rounded-full text-xs font-medium ${materia.color}`}>
                  {materia.totalTareas} tareas
                </Badge>
              </CardTitle>
              <CardDescription className="text-sm text-muted-foreground flex items-center gap-1">
                <Users className="h-3 w-3" />
                {materia.docente}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Progress value={materia.porcentaje} className="h-2 mb-2" indicatorClassName={getProgressColor(materia.porcentaje)} />
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>{materia.completadas} de {materia.totalTareas} completadas</span>
                <span className="font-medium text-foreground">{materia.porcentaje}%</span>
              </div>
              <div className="grid grid-cols-3 text-center text-xs text-muted-foreground mt-3 pt-3 border-t">
                <div>
                  <p className="font-semibold text-foreground">{materia.completadas}</p>
                  <p>Completadas</p>
                </div>
                <div>
                  <p className="font-semibold text-blue-600">{materia.pendientes}</p>
                  <p>Pendientes</p>
                </div>
                <div>
                  <p className="font-semibold text-red-600">{materia.atrasadas}</p>
                  <p>Vencidas</p>
                </div>
              </div>
              {materia.completadas > 0 && (
                <div className="mt-4 text-sm text-muted-foreground flex items-center justify-between">
                    <span>Promedio Calificaciones:</span>
                    <span className="font-medium text-foreground">{materia.promedioCalificaciones}/100</span>
                    <TooltipProvider>
                      <Tooltip>
                        <TooltipTrigger asChild>
                          <Info className="h-3 w-3 text-muted-foreground cursor-help" />
                        </TooltipTrigger>
                        <TooltipContent>
                          <p>Promedio de calificaciones en tareas completadas de esta materia.</p>
                        </TooltipContent>
                      </Tooltip>
                    </TooltipProvider>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}