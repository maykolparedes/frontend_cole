// src/pages/Index.tsx
import { useState } from "react";
import { IdCard } from "lucide-react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import {
  ParentLoginCard,
  StudentLoginCard,
  TeacherLoginCard,
  AdminLoginCard,
} from "@/components/LoginCard";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

import {
  BookOpen,
  Users,
  TrendingUp,
  Shield,
  CheckCircle,
  Star,
  Clock,
  BarChart3,
  Sparkles,
  GraduationCap,
  ShieldCheck,
  Baby,
  School,
  Library,
  CalendarDays,
  Megaphone,
  Mail,
  Phone,
  MapPin,
  ArrowRight,
  FileText,
  Send,
  Trash2,
  HeartHandshake,
  User, // <- Agregar esta importación // <- Agregar esta importación si no está // Agrega este si no está
  

} from "lucide-react";
import { toast } from "sonner";

import heroImage from "@/assets/fondo4.jpg";

const Index = () => {
  const [activeTab, setActiveTab] = useState<"login" | "features">("features");

  // ------------ HERO FEATURES/STATS ------------
  const features = [
    {
      icon: <BookOpen className="h-8 w-8 text-secondary" />,
      title: "Gestión Académica",
      description: "Notas, tareas y evaluaciones con cortes trimestrales.",
    },
    {
      icon: <Users className="h-8 w-8 text-secondary" />,
      title: "Comunicación Integrada",
      description: "Padres, estudiantes y docentes en un solo lugar.",
    },
    {
      icon: <TrendingUp className="h-8 w-8 text-secondary" />,
      title: "Reportes Avanzados",
      description: "Informes descargables y progreso por curso.",
    },
    {
      icon: <Shield className="h-8 w-8 text-secondary" />,
      title: "Seguridad Garantizada",
      description: "Privacidad y protección de datos institucionales.",
    },
  ];

  const stats = [
    {
      number: "98%",
      label: "Satisfacción de Padres",
      icon: <Star className="h-5 w-5" />,
    },
    {
      number: "45min",
      label: "Tiempo Ahorrado/Semana",
      icon: <Clock className="h-5 w-5" />,
    },
    {
      number: "100%",
      label: "Transparencia Académica",
      icon: <CheckCircle className="h-5 w-5" />,
    },
    { number: "24/7", label: "Disponibilidad", icon: <BarChart3 className="h-5 w-5" /> },
  ];

  // ------------ FORM: ADMISIONES ------------
  // Busca estas variables existentes y reemplázalas:
  const [admNombre, setAdmNombre] = useState("");
  const [admCiEstudiante, setAdmCiEstudiante] = useState("");
  const [admNivel, setAdmNivel] = useState<"" | "inicial" | "primaria" | "secundaria">("");
  const [admNombreTutor, setAdmNombreTutor] = useState("");
  const [admCiTutor, setAdmCiTutor] = useState("");
  const [admCorreo, setAdmCorreo] = useState("");
  const [admTelefono, setAdmTelefono] = useState("");
  const [admMensaje, setAdmMensaje] = useState("");

  // Y actualiza la función handleAdmision:
  const handleAdmision = (e: React.FormEvent) => {
    e.preventDefault();
    if (!admNombre || !admCiEstudiante || !admNivel || !admNombreTutor || !admCiTutor || !admCorreo || !admTelefono) {
      toast.error("Completa todos los campos obligatorios para continuar.");
      return;
    }
    toast.success("Solicitud de pre-inscripción enviada. Te contactaremos pronto.");
    // Limpiar formulario
    setAdmNombre("");
    setAdmCiEstudiante("");
    setAdmNivel("");
    setAdmNombreTutor("");
    setAdmCiTutor("");
    setAdmCorreo("");
    setAdmTelefono("");
    setAdmMensaje("");
  };

  // ------------ FORM: CONTACTO ------------
  const [ctNombre, setCtNombre] = useState("");
  const [ctCorreo, setCtCorreo] = useState("");
  const [ctMensaje, setCtMensaje] = useState("");

  const handleContacto = (e: React.FormEvent) => {
    e.preventDefault();
    if (!ctNombre || !ctCorreo || !ctMensaje) {
      toast.error("Completa nombre, correo y mensaje.");
      return;
    }
    toast.success("Mensaje enviado. ¡Gracias por escribirnos!");
    setCtNombre("");
    setCtCorreo("");
    setCtMensaje("");
  };

  return (
    <div className="min-h-screen flex flex-col bg-background font-inter">
      <Header />

      <main className="flex-1">
        {/* ===================== HERO ===================== */}
        <section
          className="relative bg-gradient-hero text-primary-foreground py-20 lg:py-32"
          style={{ scrollMarginTop: 120 }}
        >
          <div className="absolute inset-0 bg-black/20" />
          <div
            className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-30"
            style={{ backgroundImage: `url(${heroImage})` }}
          />
          <div className="relative container mx-auto px-4 text-center">
            <Badge
              variant="secondary"
              className="mb-6 text-secondary-foreground bg-secondary/20 border-secondary/30"
            >
              <Sparkles className="h-4 w-4 mr-2" />
              Unidad Educativa Privada Técnico Humanístico
            </Badge>

            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
              Seguimiento Escolar <span className="block text-accent">en Línea</span>
            </h1>

            <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto text-primary-foreground/90 leading-relaxed">
              Transparencia y acompañamiento por <b>trimestres</b> para Inicial,
              Primaria y Secundaria. Reportes descargables y comunicación en tiempo real.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <a href="#login">
                <Button variant="academicYellow" size="lg" className="text-lg px-8 py-6">
                  Comenzar Ahora
                </Button>
              </a>
              <a href="#about">
                <Button
                  variant="academicOutline"
                  size="lg"
                  className="text-lg px-8 py-6 border-primary-foreground text-primary-foreground hover:bg-primary-foreground hover:text-primary"
                >
                  Ver Características
                </Button>
              </a>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
              {stats.map((stat, index) => (
                <Card
                  key={index}
                  className="bg-primary-foreground/10 border-primary-foreground/20 backdrop-blur-sm"
                >
                  <CardContent className="p-4 text-center">
                    <div className="flex justify-center mb-2 text-accent">{stat.icon}</div>
                    <div className="text-2xl font-bold text-primary-foreground">
                      {stat.number}
                    </div>
                    <div className="text-sm text-primary-foreground/80">{stat.label}</div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* ===================== TABS (LOGIN / FEATURES) ===================== */}
        <section className="py-8 bg-muted/50" id="features" style={{ scrollMarginTop: 120 }}>
          <div className="container mx-auto px-4">
            <div className="flex justify-center mb-8">
              <div className="bg-card rounded-lg p-2 shadow-card">
                <Button
                  variant={activeTab === "features" ? "academic" : "ghost"}
                  onClick={() => setActiveTab("features")}
                  className="px-6"
                >
                  Características
                </Button>
                <Button
                  variant={activeTab === "login" ? "academic" : "ghost"}
                  onClick={() => setActiveTab("login")}
                  className="px-6"
                >
                  Acceso al Sistema
                </Button>
                
              </div>
            </div>
          </div>
        </section>

        

        {/* ====== FEATURES ====== */}
        {activeTab === "features" && (
          <section className="py-16 bg-background">
            <div className="container mx-auto px-4">
              <div className="text-center mb-12">
                <h2 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">
                  Características Principales
                </h2>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                  Todo lo que tu institución necesita para una gestión académica moderna.
                </p>
              </div>

              {/* Features Grid con animaciones mejoradas */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
                {features.map((feature, index) => (
                  <Card
                    key={index}
                    className="text-center hover:shadow-academic transition-all duration-300 group relative overflow-hidden"
                  >
                    {/* Efecto de fondo animado */}
                    <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-secondary/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    
                    {/* Efecto de borde luminoso */}
                    <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-primary/20 to-secondary/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    
                    <CardContent className="p-6 relative z-10">
                      <div className="mb-4 flex justify-center group-hover:scale-110 transition-transform duration-300">
                        <div className="relative">
                          {feature.icon}
                          {/* Efecto de pulso en el icono */}
                          <div className="absolute inset-0 rounded-full bg-primary/10 scale-0 group-hover:scale-100 transition-transform duration-300" />
                        </div>
                      </div>
                      <h3 className="text-lg font-semibold mb-3 text-foreground group-hover:text-primary transition-colors duration-300">
                        {feature.title}
                      </h3>
                      <p className="text-muted-foreground group-hover:text-foreground/80 transition-colors duration-300">
                        {feature.description}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Benefits Section mejorada */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
                {/* Card para Padres */}
                <Card className="bg-gradient-to-br from-secondary/10 to-secondary/5 border-secondary/20 hover:border-secondary/40 transition-all duration-300 group hover:shadow-lg">
                  <CardContent className="p-8">
                    <div className="flex items-center mb-6">
                      <div className="p-3 bg-secondary/20 rounded-2xl mr-4 group-hover:scale-110 transition-transform duration-300">
                        <Users className="h-6 w-6 text-secondary" />
                      </div>
                      <h3 className="text-2xl font-bold text-foreground">
                        Para Padres y Tutores
                      </h3>
                    </div>
                    <ul className="space-y-4 text-muted-foreground">
                      <li className="flex items-center space-x-3 group-hover:translate-x-2 transition-transform duration-300">
                        <div className="flex-shrink-0">
                          <CheckCircle className="h-5 w-5 text-accent" />
                        </div>
                        <span className="group-hover:text-foreground/80 transition-colors duration-300">
                          Consulta de notas y conducta en tiempo real
                        </span>
                      </li>
                      <li className="flex items-center space-x-3 group-hover:translate-x-2 transition-transform duration-300">
                        <div className="flex-shrink-0">
                          <CheckCircle className="h-5 w-5 text-accent" />
                        </div>
                        <span className="group-hover:text-foreground/80 transition-colors duration-300">
                          Calendario de tareas y evaluaciones
                        </span>
                      </li>
                      <li className="flex items-center space-x-3 group-hover:translate-x-2 transition-transform duration-300">
                        <div className="flex-shrink-0">
                          <CheckCircle className="h-5 w-5 text-accent" />
                        </div>
                        <span className="group-hover:text-foreground/80 transition-colors duration-300">
                          Reportes trimestrales descargables
                        </span>
                      </li>
                      {/* Item adicional para mejor balance visual */}
                      <li className="flex items-center space-x-3 group-hover:translate-x-2 transition-transform duration-300">
                        <div className="flex-shrink-0">
                          <CheckCircle className="h-5 w-5 text-accent" />
                        </div>
                        <span className="group-hover:text-foreground/80 transition-colors duration-300">
                          Comunicación directa con docentes
                        </span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>

                {/* Card para Docentes */}
                <Card className="bg-gradient-to-br from-primary/10 to-primary/5 border-primary/20 hover:border-primary/40 transition-all duration-300 group hover:shadow-lg">
                  <CardContent className="p-8">
                    <div className="flex items-center mb-6">
                      <div className="p-3 bg-primary/20 rounded-2xl mr-4 group-hover:scale-110 transition-transform duration-300">
                        <BookOpen className="h-6 w-6 text-primary" />
                      </div>
                      <h3 className="text-2xl font-bold text-foreground">
                        Para Docentes
                      </h3>
                    </div>
                    <ul className="space-y-4 text-muted-foreground">
                      <li className="flex items-center space-x-3 group-hover:translate-x-2 transition-transform duration-300">
                        <div className="flex-shrink-0">
                          <CheckCircle className="h-5 w-5 text-accent" />
                        </div>
                        <span className="group-hover:text-foreground/80 transition-colors duration-300">
                          Registro de calificaciones y asistencia
                        </span>
                      </li>
                      <li className="flex items-center space-x-3 group-hover:translate-x-2 transition-transform duration-300">
                        <div className="flex-shrink-0">
                          <CheckCircle className="h-5 w-5 text-accent" />
                        </div>
                        <span className="group-hover:text-foreground/80 transition-colors duration-300">
                          Planificación por nivel: inicial, primaria, secundaria
                        </span>
                      </li>
                      <li className="flex items-center space-x-3 group-hover:translate-x-2 transition-transform duration-300">
                        <div className="flex-shrink-0">
                          <CheckCircle className="h-5 w-5 text-accent" />
                        </div>
                        <span className="group-hover:text-foreground/80 transition-colors duration-300">
                          Observaciones y boletines automáticos
                        </span>
                      </li>
                      {/* Item adicional para mejor balance visual */}
                      <li className="flex items-center space-x-3 group-hover:translate-x-2 transition-transform duration-300">
                        <div className="flex-shrink-0">
                          <CheckCircle className="h-5 w-5 text-accent" />
                        </div>
                        <span className="group-hover:text-foreground/80 transition-colors duration-300">
                          Herramientas de análisis de rendimiento
                        </span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
              </div>

              {/* Sección adicional de estadísticas en tiempo real */}
              <div className="mt-16 p-8 bg-gradient-to-r from-primary/5 to-secondary/5 rounded-2xl border border-border">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
                  {[
                    { number: "500+", label: "Estudiantes Activos", icon: <Users className="h-6 w-6" /> },
                    { number: "45+", label: "Docentes Calificados", icon: <GraduationCap className="h-6 w-6" /> },
                    { number: "98%", label: "Satisfacción General", icon: <Star className="h-6 w-6" /> },
                    { number: "24/7", label: "Soporte Disponible", icon: <Shield className="h-6 w-6" /> }
                  ].map((stat, index) => (
                    <div key={index} className="text-center group">
                      <div className="flex justify-center mb-3 text-primary group-hover:scale-110 transition-transform duration-300">
                        {stat.icon}
                      </div>
                      <div className="text-2xl font-bold text-foreground mb-1">
                        {stat.number}
                      </div>
                      <div className="text-sm text-muted-foreground group-hover:text-foreground/80 transition-colors duration-300">
                        {stat.label}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </section>
        )}

        {/* ===================== NOSOTROS ===================== */}
        <section id="about" className="py-20 bg-white relative overflow-hidden" style={{ scrollMarginTop: 120 }}>
          {/* Fondo animado con partículas */}
          <div className="absolute inset-0 z-0">
            {/* Partículas flotantes */}
            <div className="absolute inset-0">
              {[...Array(15)].map((_, i) => (
                <div
                  key={i}
                  className="absolute rounded-full bg-gradient-to-r from-blue-200 to-purple-200 opacity-20 animate-float"
                  style={{
                    width: `${Math.random() * 20 + 5}px`,
                    height: `${Math.random() * 20 + 5}px`,
                    top: `${Math.random() * 100}%`,
                    left: `${Math.random() * 100}%`,
                    animationDelay: `${Math.random() * 5}s`,
                    animationDuration: `${Math.random() * 10 + 10}s`,
                  }}
                />
              ))}
            </div>
            
            {/* Ondas de fondo */}
            <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-blue-50/30 to-transparent" />
            <div className="absolute top-0 left-0 right-0 h-32 bg-gradient-to-b from-purple-50/30 to-transparent" />
          </div>

          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-4xl mx-auto text-center mb-16">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-purple-100 text-purple-700 rounded-full text-sm font-medium mb-4 hover:scale-105 transition-transform duration-300 cursor-default">
                <HeartHandshake className="h-4 w-4" />
                Nuestra Filosofía
              </div>
              
              <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-slate-800 to-slate-600 bg-clip-text text-transparent hover:from-blue-600 hover:to-purple-600 transition-all duration-500">
                Formación Integral con Valores
              </h2>
              
              <p className="text-xl text-slate-600 leading-relaxed hover:text-slate-800 transition-colors duration-300">
                Enfoque técnico humanístico para el desarrollo de competencias y ciudadanía digital.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {/* Misión Card */}
              <Card className="border-0 shadow-lg hover:shadow-2xl transition-all duration-500 rounded-2xl overflow-hidden group relative bg-white/80 backdrop-blur-sm">
                {/* Efecto de brillo al hover */}
                <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl" />
                
                <CardHeader className="pb-4 relative z-10">
                  <div className="flex items-start justify-between">
                    <div className="p-3 bg-blue-50 rounded-2xl w-fit group-hover:scale-110 group-hover:rotate-12 transition-all duration-300">
                      <BookOpen className="h-6 w-6 text-blue-600" />
                    </div>
                    <div className="text-4xl font-bold text-blue-100 group-hover:text-blue-200 transition-colors duration-300">
                      01
                    </div>
                  </div>
                  <CardTitle className="text-xl font-bold text-slate-800 mt-4 group-hover:text-blue-700 transition-colors duration-300">
                    Misión
                  </CardTitle>
                </CardHeader>
                <CardContent className="relative z-10">
                  <p className="text-slate-600 leading-relaxed group-hover:text-slate-700 transition-colors duration-300">
                    Educar personas críticas y creativas que resuelvan problemas reales con
                    ética, ciencia y tecnología.
                  </p>
                  
                  {/* Elementos interactivos adicionales */}
                  <div className="mt-6 pt-4 border-t border-blue-100 group-hover:border-blue-200 transition-colors duration-300">
                    <div className="flex items-center gap-2 text-sm text-blue-600">
                      <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse" />
                      <span className="font-medium">Innovación Educativa</span>
                    </div>
                  </div>
                </CardContent>
                
                {/* Efecto de borde animado */}
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-blue-400 to-purple-400 opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-10">
                  <div className="absolute inset-[2px] rounded-2xl bg-white" />
                </div>
              </Card>
              
              {/* Visión Card */}
              <Card className="border-0 shadow-lg hover:shadow-2xl transition-all duration-500 rounded-2xl overflow-hidden group relative bg-white/80 backdrop-blur-sm">
                {/* Efecto de brillo al hover */}
                <div className="absolute inset-0 bg-gradient-to-br from-green-50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl" />
                
                <CardHeader className="pb-4 relative z-10">
                  <div className="flex items-start justify-between">
                    <div className="p-3 bg-green-50 rounded-2xl w-fit group-hover:scale-110 group-hover:-rotate-12 transition-all duration-300">
                      <GraduationCap className="h-6 w-6 text-green-600" />
                    </div>
                    <div className="text-4xl font-bold text-green-100 group-hover:text-green-200 transition-colors duration-300">
                      02
                    </div>
                  </div>
                  <CardTitle className="text-xl font-bold text-slate-800 mt-4 group-hover:text-green-700 transition-colors duration-300">
                    Visión
                  </CardTitle>
                </CardHeader>
                <CardContent className="relative z-10">
                  <p className="text-slate-600 leading-relaxed group-hover:text-slate-700 transition-colors duration-300">
                    Ser referentes por innovación, inclusión y logros académicos sostenidos.
                  </p>
                  
                  {/* Elementos interactivos adicionales */}
                  <div className="mt-6 pt-4 border-t border-green-100 group-hover:border-green-200 transition-colors duration-300">
                    <div className="flex items-center gap-2 text-sm text-green-600">
                      <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                      <span className="font-medium">Liderazgo Educativo</span>
                    </div>
                  </div>
                </CardContent>
                
                {/* Efecto de borde animado */}
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-green-400 to-emerald-400 opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-10">
                  <div className="absolute inset-[2px] rounded-2xl bg-white" />
                </div>
              </Card>
              
              {/* Compromiso Card */}
              <Card className="border-0 shadow-lg hover:shadow-2xl transition-all duration-500 rounded-2xl overflow-hidden group relative bg-white/80 backdrop-blur-sm">
                {/* Efecto de brillo al hover */}
                <div className="absolute inset-0 bg-gradient-to-br from-orange-50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 rounded-2xl" />
                
                <CardHeader className="pb-4 relative z-10">
                  <div className="flex items-start justify-between">
                    <div className="p-3 bg-orange-50 rounded-2xl w-fit group-hover:scale-110 group-hover:rotate-12 transition-all duration-300">
                      <ShieldCheck className="h-6 w-6 text-orange-600" />
                    </div>
                    <div className="text-4xl font-bold text-orange-100 group-hover:text-orange-200 transition-colors duration-300">
                      03
                    </div>
                  </div>
                  <CardTitle className="text-xl font-bold text-slate-800 mt-4 group-hover:text-orange-700 transition-colors duration-300">
                    Compromiso
                  </CardTitle>
                </CardHeader>
                <CardContent className="relative z-10">
                  <p className="text-slate-600 leading-relaxed group-hover:text-slate-700 transition-colors duration-300">
                    Procesos transparentes, evaluación formativa y comunicación permanente con
                    las familias.
                  </p>
                  
                  {/* Elementos interactivos adicionales */}
                  <div className="mt-6 pt-4 border-t border-orange-100 group-hover:border-orange-200 transition-colors duration-300">
                    <div className="flex items-center gap-2 text-sm text-orange-600">
                      <div className="w-2 h-2 bg-orange-400 rounded-full animate-pulse" />
                      <span className="font-medium">Transparencia Total</span>
                    </div>
                  </div>
                </CardContent>
                
                {/* Efecto de borde animado */}
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-orange-400 to-red-400 opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-10">
                  <div className="absolute inset-[2px] rounded-2xl bg-white" />
                </div>
              </Card>
            </div>

            {/* Sección adicional de valores */}
            <div className="mt-16 max-w-4xl mx-auto">
              <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-2xl p-8 border border-blue-100 hover:border-blue-200 transition-all duration-300">
                <h3 className="text-2xl font-bold text-center text-slate-800 mb-6">
                  Nuestros Valores Fundamentales
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {[
                    { name: "Integridad", icon: "🛡️", color: "blue" },
                    { name: "Innovación", icon: "💡", color: "purple" },
                    { name: "Inclusión", icon: "🤝", color: "green" },
                    { name: "Excelencia", icon: "⭐", color: "orange" }
                  ].map((value, index) => (
                    <div
                      key={index}
                      className="text-center p-4 rounded-xl bg-white hover:shadow-lg transition-all duration-300 group cursor-default"
                    >
                      <div className="text-2xl mb-2 group-hover:scale-125 transition-transform duration-300">
                        {value.icon}
                      </div>
                      <div className={`font-semibold text-${value.color}-600 group-hover:text-${value.color}-700 transition-colors duration-300`}>
                        {value.name}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* ===================== NIVELES ===================== */}
        <section id="niveles" className="py-20 bg-gradient-to-br from-slate-50 to-blue-50 relative overflow-hidden" style={{ scrollMarginTop: 120 }}>
          {/* Fondo animado con elementos educativos */}
          <div className="absolute inset-0 z-0">
            {/* Formas geométricas flotantes */}
            {[...Array(8)].map((_, i) => (
              <div
                key={i}
                className="absolute opacity-10 animate-float-slow"
                style={{
                  width: `${Math.random() * 40 + 20}px`,
                  height: `${Math.random() * 40 + 20}px`,
                  top: `${Math.random() * 100}%`,
                  left: `${Math.random() * 100}%`,
                  animationDelay: `${Math.random() * 8}s`,
                  background: `conic-gradient(from ${Math.random() * 360}deg, #3b82f6, #8b5cf6, #06b6d4, #3b82f6)`,
                  borderRadius: i % 2 === 0 ? '50%' : '20%',
                }}
              />
            ))}
            
            {/* Patrón de puntos educativos */}
            <div className="absolute inset-0 opacity-5">
              <div className="grid grid-cols-12 gap-8 w-full h-full">
                {[...Array(48)].map((_, i) => (
                  <div
                    key={i}
                    className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"
                    style={{
                      animationDelay: `${(i % 6) * 0.5}s`,
                    }}
                  />
                ))}
              </div>
            </div>
          </div>

          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-4xl mx-auto text-center mb-16">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-medium mb-4 hover:scale-105 transition-transform duration-300 cursor-default group">
                <GraduationCap className="h-4 w-4 group-hover:rotate-12 transition-transform duration-300" />
                Niveles Educativos
              </div>
              
              <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-blue-800 to-purple-700 bg-clip-text text-transparent hover:from-blue-600 hover:to-purple-600 transition-all duration-500">
                Inicial, Primaria y Secundaria
              </h2>
              
              <p className="text-xl text-slate-600 leading-relaxed hover:text-slate-800 transition-colors duration-300">
                Planes por trimestres, progreso visible y reportes descargables para cada etapa.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
              {/* Nivel Inicial - Mejorado */}
              <Card className="border-0 shadow-xl hover:shadow-2xl transition-all duration-500 rounded-2xl overflow-hidden group relative bg-white/90 backdrop-blur-sm hover:bg-white">
                {/* Efecto de borde gradiente animado */}
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-pink-400 to-rose-400 opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-10">
                  <div className="absolute inset-[2px] rounded-2xl bg-white" />
                </div>
                
                {/* Indicador de nivel */}
                <div className="absolute -top-3 -right-3 w-12 h-12 bg-pink-500 text-white rounded-full flex items-center justify-center text-sm font-bold shadow-lg group-hover:scale-110 transition-transform duration-300">
                  3-5
                </div>

                <CardHeader className="pb-4 relative z-10">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <div className="p-3 bg-pink-50 rounded-2xl group-hover:scale-110 group-hover:rotate-12 transition-all duration-300">
                        <Baby className="h-6 w-6 text-pink-600" />
                      </div>
                      {/* Punto de actividad */}
                      <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full border-2 border-white animate-pulse" />
                    </div>
                    <CardTitle className="text-xl font-bold text-slate-800 group-hover:text-pink-700 transition-colors duration-300">
                      Nivel Inicial
                    </CardTitle>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4 relative z-10">
                  <ul className="space-y-3 text-slate-600">
                    <li className="flex items-start space-x-3 group-hover:translate-x-2 transition-transform duration-300">
                      <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0 group-hover:scale-110 transition-transform duration-300" />
                      <span className="group-hover:text-slate-800 transition-colors duration-300">Psicomotricidad, pre-matemática y lenguaje</span>
                    </li>
                    <li className="flex items-start space-x-3 group-hover:translate-x-2 transition-transform duration-300">
                      <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0 group-hover:scale-110 transition-transform duration-300" />
                      <span className="group-hover:text-slate-800 transition-colors duration-300">Juegos, arte y trabajo con familias</span>
                    </li>
                    <li className="flex items-start space-x-3 group-hover:translate-x-2 transition-transform duration-300">
                      <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0 group-hover:scale-110 transition-transform duration-300" />
                      <span className="group-hover:text-slate-800 transition-colors duration-300">Evaluación formativa amistosa</span>
                    </li>
                  </ul>
                  
                  {/* Información adicional interactiva */}
                  <div className="pt-4 border-t border-pink-100 group-hover:border-pink-200 transition-colors duration-300">
                    <div className="flex items-center justify-between text-sm text-pink-600">
                      <span className="font-medium">Edades: 3-5 años</span>
                      <span className="bg-pink-100 px-2 py-1 rounded-full">💫 Creatividad</span>
                    </div>
                  </div>
                  
                  <div className="flex gap-3 pt-4">
                    <a href="#login">
                      <Button className="bg-blue-600 hover:bg-blue-700 text-white rounded-xl group/btn transition-all duration-300 hover:shadow-lg">
                        <span className="group-hover/btn:translate-x-1 transition-transform duration-300">Ingresar</span>
                        <ArrowRight className="ml-2 h-4 w-4 group-hover/btn:translate-x-1 transition-transform duration-300" />
                      </Button>
                    </a>
                    <a href="#admisiones">
                      <Button variant="outline" className="rounded-xl hover:border-pink-300 hover:text-pink-600 transition-all duration-300">
                        Admisiones
                      </Button>
                    </a>
                  </div>
                </CardContent>
              </Card>

              {/* Nivel Primaria - Mejorado */}
              <Card className="border-0 shadow-xl hover:shadow-2xl transition-all duration-500 rounded-2xl overflow-hidden group relative bg-white/90 backdrop-blur-sm hover:bg-white">
                {/* Efecto de borde gradiente animado */}
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-emerald-400 to-green-400 opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-10">
                  <div className="absolute inset-[2px] rounded-2xl bg-white" />
                </div>
                
                {/* Indicador de nivel */}
                <div className="absolute -top-3 -right-3 w-12 h-12 bg-emerald-500 text-white rounded-full flex items-center justify-center text-sm font-bold shadow-lg group-hover:scale-110 transition-transform duration-300">
                  6-11
                </div>

                <CardHeader className="pb-4 relative z-10">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <div className="p-3 bg-emerald-50 rounded-2xl group-hover:scale-110 group-hover:-rotate-12 transition-all duration-300">
                        <School className="h-6 w-6 text-emerald-600" />
                      </div>
                      {/* Punto de actividad */}
                      <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full border-2 border-white animate-pulse" />
                    </div>
                    <CardTitle className="text-xl font-bold text-slate-800 group-hover:text-emerald-700 transition-colors duration-300">
                      Nivel Primaria
                    </CardTitle>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4 relative z-10">
                  <ul className="space-y-3 text-slate-600">
                    <li className="flex items-start space-x-3 group-hover:translate-x-2 transition-transform duration-300">
                      <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0 group-hover:scale-110 transition-transform duration-300" />
                      <span className="group-hover:text-slate-800 transition-colors duration-300">Comunicación, Matemática, Ciencia y Arte</span>
                    </li>
                    <li className="flex items-start space-x-3 group-hover:translate-x-2 transition-transform duration-300">
                      <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0 group-hover:scale-110 transition-transform duration-300" />
                      <span className="group-hover:text-slate-800 transition-colors duration-300">Proyectos STEAM iniciales</span>
                    </li>
                    <li className="flex items-start space-x-3 group-hover:translate-x-2 transition-transform duration-300">
                      <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0 group-hover:scale-110 transition-transform duration-300" />
                      <span className="group-hover:text-slate-800 transition-colors duration-300">Hábitos y ciudadanía digital</span>
                    </li>
                  </ul>
                  
                  {/* Información adicional interactiva */}
                  <div className="pt-4 border-t border-emerald-100 group-hover:border-emerald-200 transition-colors duration-300">
                    <div className="flex items-center justify-between text-sm text-emerald-600">
                      <span className="font-medium">Edades: 6-11 años</span>
                      <span className="bg-emerald-100 px-2 py-1 rounded-full">🔬 Exploración</span>
                    </div>
                  </div>
                  
                  <div className="flex gap-3 pt-4">
                    <a href="#login">
                      <Button className="bg-blue-600 hover:bg-blue-700 text-white rounded-xl group/btn transition-all duration-300 hover:shadow-lg">
                        <span className="group-hover/btn:translate-x-1 transition-transform duration-300">Ingresar</span>
                        <ArrowRight className="ml-2 h-4 w-4 group-hover/btn:translate-x-1 transition-transform duration-300" />
                      </Button>
                    </a>
                    <a href="#admisiones">
                      <Button variant="outline" className="rounded-xl hover:border-emerald-300 hover:text-emerald-600 transition-all duration-300">
                        Admisiones
                      </Button>
                    </a>
                  </div>
                </CardContent>
              </Card>

              {/* Nivel Secundaria - Mejorado */}
              <Card className="border-0 shadow-xl hover:shadow-2xl transition-all duration-500 rounded-2xl overflow-hidden group relative bg-white/90 backdrop-blur-sm hover:bg-white">
                {/* Efecto de borde gradiente animado */}
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-indigo-400 to-purple-400 opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-10">
                  <div className="absolute inset-[2px] rounded-2xl bg-white" />
                </div>
                
                {/* Indicador de nivel */}
                <div className="absolute -top-3 -right-3 w-12 h-12 bg-indigo-500 text-white rounded-full flex items-center justify-center text-sm font-bold shadow-lg group-hover:scale-110 transition-transform duration-300">
                  12-16
                </div>

                <CardHeader className="pb-4 relative z-10">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <div className="p-3 bg-indigo-50 rounded-2xl group-hover:scale-110 group-hover:rotate-12 transition-all duration-300">
                        <Library className="h-6 w-6 text-indigo-600" />
                      </div>
                      {/* Punto de actividad */}
                      <div className="absolute -top-1 -right-1 w-3 h-3 bg-green-400 rounded-full border-2 border-white animate-pulse" />
                    </div>
                    <CardTitle className="text-xl font-bold text-slate-800 group-hover:text-indigo-700 transition-colors duration-300">
                      Nivel Secundaria
                    </CardTitle>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4 relative z-10">
                  <ul className="space-y-3 text-slate-600">
                    <li className="flex items-start space-x-3 group-hover:translate-x-2 transition-transform duration-300">
                      <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0 group-hover:scale-110 transition-transform duration-300" />
                      <span className="group-hover:text-slate-800 transition-colors duration-300">Profundización científica y humanística</span>
                    </li>
                    <li className="flex items-start space-x-3 group-hover:translate-x-2 transition-transform duration-300">
                      <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0 group-hover:scale-110 transition-transform duration-300" />
                      <span className="group-hover:text-slate-800 transition-colors duration-300">Proyectos técnicos y emprendimiento</span>
                    </li>
                    <li className="flex items-start space-x-3 group-hover:translate-x-2 transition-transform duration-300">
                      <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0 group-hover:scale-110 transition-transform duration-300" />
                      <span className="group-hover:text-slate-800 transition-colors duration-300">Orientación vocacional</span>
                    </li>
                  </ul>
                  
                  {/* Información adicional interactiva */}
                  <div className="pt-4 border-t border-indigo-100 group-hover:border-indigo-200 transition-colors duration-300">
                    <div className="flex items-center justify-between text-sm text-indigo-600">
                      <span className="font-medium">Edades: 12-16 años</span>
                      <span className="bg-indigo-100 px-2 py-1 rounded-full">🚀 Innovación</span>
                    </div>
                  </div>
                  
                  <div className="flex gap-3 pt-4">
                    <a href="#login">
                      <Button className="bg-blue-600 hover:bg-blue-700 text-white rounded-xl group/btn transition-all duration-300 hover:shadow-lg">
                        <span className="group-hover/btn:translate-x-1 transition-transform duration-300">Ingresar</span>
                        <ArrowRight className="ml-2 h-4 w-4 group-hover/btn:translate-x-1 transition-transform duration-300" />
                      </Button>
                    </a>
                    <a href="#admisiones">
                      <Button variant="outline" className="rounded-xl hover:border-indigo-300 hover:text-indigo-600 transition-all duration-300">
                        Admisiones
                      </Button>
                    </a>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sección adicional de características comunes */}
            <div className="mt-16 max-w-4xl mx-auto">
              <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-8 border border-blue-100 hover:border-blue-200 transition-all duration-300 shadow-lg">
                <h3 className="text-2xl font-bold text-center text-slate-800 mb-8">
                  Características Comunes a Todos los Niveles
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {[
                    { 
                      title: "Seguimiento Trimestral", 
                      description: "Evaluación continua con 3 cortes al año",
                      icon: "📊",
                      color: "blue"
                    },
                    { 
                      title: "Plataforma Digital", 
                      description: "Acceso 24/7 para padres y estudiantes",
                      icon: "💻",
                      color: "green"
                    },
                    { 
                      title: "Reportes Automáticos", 
                      description: "Descarga de boletines y progreso",
                      icon: "📄",
                      color: "purple"
                    }
                  ].map((feature, index) => (
                    <div
                      key={index}
                      className="text-center p-6 rounded-xl bg-gradient-to-br from-white to-gray-50 hover:shadow-lg transition-all duration-300 group cursor-default"
                    >
                      <div className="text-3xl mb-4 group-hover:scale-110 transition-transform duration-300">
                        {feature.icon}
                      </div>
                      <h4 className={`font-bold text-${feature.color}-600 mb-2 group-hover:text-${feature.color}-700 transition-colors duration-300`}>
                        {feature.title}
                      </h4>
                      <p className="text-slate-600 text-sm leading-relaxed">
                        {feature.description}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

        </section>

        {/* ===================== ADMISIONES ===================== */}
        <section id="admisiones" className="py-20 bg-white relative overflow-hidden" style={{ scrollMarginTop: 120 }}>
          {/* Fondo animado con elementos educativos */}
          <div className="absolute inset-0 z-0">
            {/* Partículas de fondo animadas */}
            {[...Array(12)].map((_, i) => (
              <div
                key={i}
                className="absolute rounded-full animate-float-slow opacity-10"
                style={{
                  width: `${Math.random() * 30 + 10}px`,
                  height: `${Math.random() * 30 + 10}px`,
                  top: `${Math.random() * 100}%`,
                  left: `${Math.random() * 100}%`,
                  animationDelay: `${Math.random() * 6}s`,
                  background: `conic-gradient(from ${Math.random() * 360}deg, #10b981, #059669, #34d399, #10b981)`,
                }}
              />
            ))}
            
            {/* Líneas de conexión animadas */}
            <div className="absolute inset-0 opacity-5">
              <svg width="100%" height="100%" className="animate-pulse-slow">
                <defs>
                  <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#3b82f6" />
                    <stop offset="50%" stopColor="#10b981" />
                    <stop offset="100%" stopColor="#8b5cf6" />
                  </linearGradient>
                </defs>
                <path
                  d="M10,10 L100,100 L200,50 L300,150"
                  stroke="url(#gradient)"
                  strokeWidth="2"
                  fill="none"
                  strokeDasharray="5,5"
                />
              </svg>
            </div>
          </div>

          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-4xl mx-auto text-center mb-16">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-green-100 text-green-700 rounded-full text-sm font-medium mb-4 hover:scale-105 transition-transform duration-300 cursor-default group">
                <CalendarDays className="h-4 w-4 group-hover:rotate-12 transition-transform duration-300" />
                Proceso de Admisión
              </div>
              
              <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-slate-800 to-slate-600 bg-clip-text text-transparent hover:from-green-600 hover:to-blue-600 transition-all duration-500">
                Matrícula en Línea - UEP Técnico Humanístico Ebenezer
              </h2>
              
              <p className="text-xl text-slate-600 leading-relaxed hover:text-slate-800 transition-colors duration-300">
                Déjanos tus datos y te contactaremos para continuar con el proceso de pre-inscripción según los lineamientos del Sistema Educativo Plurinacional.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
              {/* Formulario de Pre-Inscripción - Adaptado para Bolivia */}
              <Card className="border-0 shadow-xl rounded-2xl overflow-hidden group relative bg-white/95 backdrop-blur-sm hover:shadow-2xl transition-all duration-500">
                {/* Efecto de borde gradiente animado */}
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-blue-400 to-green-400 opacity-0 group-hover:opacity-100 transition-opacity duration-500 -z-10">
                  <div className="absolute inset-[2px] rounded-2xl bg-white" />
                </div>

                <CardHeader className="pb-4 relative z-10">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl font-bold text-slate-800 flex items-center gap-3 group-hover:text-blue-600 transition-colors duration-300">
                      <div className="p-2 bg-blue-50 rounded-xl group-hover:scale-110 group-hover:rotate-12 transition-all duration-300">
                        <CalendarDays className="h-6 w-6 text-blue-600" />
                      </div>
                      Formulario de Pre-Inscripción
                    </CardTitle>
                    {/* Contador de progreso */}
                    <div className="text-sm text-slate-400">
                      Progreso: {[admNombre, admCiEstudiante, admNivel, admNombreTutor, admCiTutor, admCorreo, admTelefono].filter(Boolean).length}/7
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent className="relative z-10">
                  <form className="space-y-4" onSubmit={handleAdmision}>
                    {/* Información del Estudiante */}
                    <div className="space-y-4">
                      <h4 className="font-semibold text-slate-700 border-b pb-2">Información del Estudiante</h4>
                      
                      {/* Nombre del Estudiante */}
                      <div className="relative">
                        <Input
                          placeholder="Nombre y Apellidos completos del estudiante"
                          value={admNombre}
                          onChange={(e) => setAdmNombre(e.target.value)}
                          className="rounded-xl py-3 pl-10 border-slate-200 hover:border-blue-300 focus:border-blue-400 transition-all duration-300"
                          required
                        />
                        <Users className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
                        {admNombre && (
                          <CheckCircle className="h-4 w-4 text-green-500 absolute right-3 top-1/2 transform -translate-y-1/2" />
                        )}
                      </div>

                      {/* CI del Estudiante */}
                      <div className="relative">
                        <Input
                          placeholder="Número de Cédula de Identidad del estudiante"
                          value={admCiEstudiante}
                          onChange={(e) => setAdmCiEstudiante(e.target.value.replace(/[^0-9a-zA-Z]/g, ''))}
                          className="rounded-xl py-3 pl-10 border-slate-200 hover:border-blue-300 focus:border-blue-400 transition-all duration-300 font-mono"
                          required
                        />
                        <IdCard className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
                        {admCiEstudiante && (
                          <CheckCircle className="h-4 w-4 text-green-500 absolute right-3 top-1/2 transform -translate-y-1/2" />
                        )}
                      </div>

                      {/* Nivel Educativo */}
                      <div className="relative">
                        <select
                          className="h-12 rounded-xl border border-slate-200 bg-background px-10 text-sm w-full appearance-none hover:border-blue-300 focus:border-blue-400 transition-all duration-300"
                          value={admNivel}
                          onChange={(e) =>
                            setAdmNivel(e.target.value as "inicial" | "primaria" | "secundaria" | "")
                          }
                          required
                        >
                          <option value="">Selecciona el nivel al que postula</option>
                          <option value="inicial">🏫 Educación Inicial en Familia Comunitaria (Pre-Kínder / Kínder)</option>
                          <option value="primaria">📚 Educación Primaria Comunitaria Vocacional (1ro a 6to)</option>
                          <option value="secundaria">🎯 Educación Secundaria Comunitaria Productiva (1ro a 6to)</option>
                        </select>
                        <GraduationCap className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
                        {admNivel && (
                          <CheckCircle className="h-4 w-4 text-green-500 absolute right-3 top-1/2 transform -translate-y-1/2" />
                        )}
                      </div>
                    </div>

                    {/* Información del Tutor */}
                    <div className="space-y-4 pt-4">
                      <h4 className="font-semibold text-slate-700 border-b pb-2">Información del Padre/Madre/Tutor</h4>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Nombre del Tutor */}
                        <div className="relative">
                          <Input
                            placeholder="Nombre y Apellidos del tutor"
                            value={admNombreTutor}
                            onChange={(e) => setAdmNombreTutor(e.target.value)}
                            className="rounded-xl py-3 pl-10 border-slate-200 hover:border-blue-300 focus:border-blue-400 transition-all duration-300"
                            required
                          />
                          <User className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
                          {admNombreTutor && (
                            <CheckCircle className="h-4 w-4 text-green-500 absolute right-3 top-1/2 transform -translate-y-1/2" />
                          )}
                        </div>

                        {/* CI del Tutor */}
                        <div className="relative">
                          <Input
                            placeholder="CI del tutor"
                            value={admCiTutor}
                            onChange={(e) => setAdmCiTutor(e.target.value.replace(/[^0-9a-zA-Z]/g, ''))}
                            className="rounded-xl py-3 pl-10 border-slate-200 hover:border-blue-300 focus:border-blue-400 transition-all duration-300 font-mono"
                            required
                          />
                          <IdCard className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
                          {admCiTutor && (
                            <CheckCircle className="h-4 w-4 text-green-500 absolute right-3 top-1/2 transform -translate-y-1/2" />
                          )}
                        </div>
                      </div>

                      {/* Contacto */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {/* Email */}
                        <div className="relative">
                          <Input
                            placeholder="Correo electrónico"
                            type="email"
                            value={admCorreo}
                            onChange={(e) => setAdmCorreo(e.target.value)}
                            className="rounded-xl py-3 pl-10 border-slate-200 hover:border-blue-300 focus:border-blue-400 transition-all duration-300"
                            required
                          />
                          <Mail className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
                          {admCorreo && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(admCorreo) && (
                            <CheckCircle className="h-4 w-4 text-green-500 absolute right-3 top-1/2 transform -translate-y-1/2" />
                          )}
                        </div>

                        {/* Teléfono */}
                        <div className="relative">
                          <Input
                            placeholder="Número de teléfono/celular"
                            type="tel"
                            value={admTelefono}
                            onChange={(e) => setAdmTelefono(e.target.value)}
                            className="rounded-xl py-3 pl-10 border-slate-200 hover:border-blue-300 focus:border-blue-400 transition-all duration-300"
                            required
                          />
                          <Phone className="h-4 w-4 text-slate-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
                          {admTelefono && (
                            <CheckCircle className="h-4 w-4 text-green-500 absolute right-3 top-1/2 transform -translate-y-1/2" />
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Información Adicional */}
                    <div className="relative">
                      <Textarea
                        placeholder="Información adicional o consulta (opcional)"
                        value={admMensaje}
                        onChange={(e) => setAdmMensaje(e.target.value.slice(0, 500))}
                        className="rounded-xl min-h-[100px] pr-16 border-slate-200 hover:border-blue-300 focus:border-blue-400 transition-all duration-300 resize-none"
                      />
                      <div className="absolute bottom-3 right-3 text-xs text-slate-400">
                        {admMensaje.length}/500
                      </div>
                    </div>

                    {/* Botones */}
                    <div className="flex gap-3 pt-2">
                      <Button 
                        type="submit" 
                        className="rounded-xl flex-1 bg-gradient-to-r from-blue-600 to-green-600 hover:from-blue-700 hover:to-green-700 text-white shadow-lg hover:shadow-xl transition-all duration-300 group/btn relative overflow-hidden"
                        disabled={!admNombre || !admCiEstudiante || !admNivel || !admNombreTutor || !admCiTutor || !admCorreo || !admTelefono}
                      >
                        {/* Efecto de brillo al hover */}
                        <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover/btn:opacity-100 transition-opacity duration-300 transform -skew-x-12 -translate-x-full group-hover/btn:translate-x-full" />
                        
                        <span className="relative z-10 flex items-center justify-center">
                          <CheckCircle className="h-4 w-4 mr-2 group-hover/btn:scale-110 transition-transform duration-300" />
                          Enviar Solicitud de Pre-Inscripción
                        </span>
                      </Button>
                      
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => {
                          setAdmNombre("");
                          setAdmCiEstudiante("");
                          setAdmNivel("");
                          setAdmNombreTutor("");
                          setAdmCiTutor("");
                          setAdmCorreo("");
                          setAdmTelefono("");
                          setAdmMensaje("");
                        }}
                        className="rounded-xl hover:bg-red-50 hover:text-red-600 hover:border-red-200 transition-all duration-300 group/reset"
                        disabled={!admNombre && !admCiEstudiante && !admNivel && !admNombreTutor && !admCiTutor && !admCorreo && !admTelefono && !admMensaje}
                      >
                        <svg className="h-4 w-4 mr-2 group-hover/reset:scale-110 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                        Limpiar
                      </Button>
                    </div>

                    {/* Indicador de progreso del formulario */}
                    <div className="pt-4">
                      <div className="flex items-center justify-between text-sm text-slate-500 mb-2">
                        <span>Progreso del formulario</span>
                        <span>
                          {[admNombre, admCiEstudiante, admNivel, admNombreTutor, admCiTutor, admCorreo, admTelefono].filter(Boolean).length}/7
                        </span>
                      </div>
                      <div className="w-full bg-slate-200 rounded-full h-2">
                        <div 
                          className="bg-gradient-to-r from-blue-500 to-green-500 h-2 rounded-full transition-all duration-500 ease-out"
                          style={{
                            width: `${([admNombre, admCiEstudiante, admNivel, admNombreTutor, admCiTutor, admCorreo, admTelefono].filter(Boolean).length / 7) * 100}%`
                          }}
                        />
                      </div>
                    </div>
                  </form>
                </CardContent>
              </Card>

              {/* Información de Admisión - Adaptada para Bolivia */}
              <div className="space-y-6">
                {/* Card de Requisitos */}
                <Card className="border-0 shadow-xl bg-gradient-to-br from-slate-50 to-green-50 rounded-2xl overflow-hidden group hover:shadow-2xl transition-all duration-500">
                  <CardContent className="p-6 space-y-4">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="p-2 bg-green-100 rounded-xl group-hover:scale-110 transition-transform duration-300">
                        <FileText className="h-5 w-5 text-green-600" />
                      </div>
                      <h3 className="text-xl font-bold text-slate-800 group-hover:text-green-700 transition-colors duration-300">
                        Requisitos de Admisión (Para la Formalización)
                      </h3>
                    </div>
                    
                    <div className="space-y-4">
                      {/* Documentación Académica */}
                      <div>
                        <h4 className="font-semibold text-slate-700 mb-2 flex items-center gap-2">
                          <span className="text-lg">📘</span>
                          Documentación Académica
                        </h4>
                        <ul className="space-y-2 text-slate-600">
                          <li className="flex items-start gap-2">
                            <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <span>Libreta de Calificaciones o Certificado de Promoción del grado anterior <span className="text-orange-600 font-medium">(Obligatorio para Primaria y Secundaria)</span></span>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <span>Certificado de Nacimiento original y una copia <span className="text-orange-600 font-medium">(Obligatorio para todos los niveles)</span></span>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <span>Para Inicial: Carnet de Vacunas actualizado</span>
                          </li>
                        </ul>
                      </div>

                      {/* Documentos de Identidad */}
                      <div>
                        <h4 className="font-semibold text-slate-700 mb-2 flex items-center gap-2">
                          <span className="text-lg">🆔</span>
                          Documentos de Identidad
                        </h4>
                        <ul className="space-y-2 text-slate-600">
                          <li className="flex items-start gap-2">
                            <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <span>Fotocopia de la Cédula de Identidad del estudiante (si es mayor a 5 años) o fotocopia del Certificado de Nacimiento</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <span>Fotocopia de la Cédula de Identidad del Padre, Madre o Tutor legal</span>
                          </li>
                        </ul>
                      </div>

                      {/* Otros */}
                      <div>
                        <h4 className="font-semibold text-slate-700 mb-2 flex items-center gap-2">
                          <span className="text-lg">📸</span>
                          Otros
                        </h4>
                        <ul className="space-y-2 text-slate-600">
                          <li className="flex items-start gap-2">
                            <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <span>2 fotografías tamaño carnet (fondos y colores según reglamento de la unidad educativa)</span>
                          </li>
                          <li className="flex items-start gap-2">
                            <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                            <span>Comprobante de domicilio (Factura de luz, agua o teléfono a nombre del tutor)</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Card de Proceso */}
                <Card className="border-0 shadow-xl bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl overflow-hidden group hover:shadow-2xl transition-all duration-500">
                  <CardContent className="p-6 space-y-4">
                    <div className="flex items-center gap-3 mb-4">
                      <div className="p-2 bg-blue-100 rounded-xl group-hover:scale-110 transition-transform duration-300">
                        <CalendarDays className="h-5 w-5 text-blue-600" />
                      </div>
                      <h3 className="text-xl font-bold text-slate-800 group-hover:text-blue-700 transition-colors duration-300">
                        Proceso de Admisión (Adaptado a Bolivia)
                      </h3>
                    </div>
                    
                    <div className="space-y-4">
                      {[
                        { 
                          step: 1, 
                          title: "Pre-inscripción en Línea", 
                          description: "Completa el formulario inicial con tus datos de contacto e información básica.", 
                          duration: "24-48 horas hábiles" 
                        },
                        { 
                          step: 2, 
                          title: "Contacto y Verificación de Cupo", 
                          description: "Un representante del colegio se comunicará contigo para confirmar la disponibilidad de cupo y coordinar los siguientes pasos.", 
                          duration: "2-3 días hábiles" 
                        },
                        { 
                          step: 3, 
                          title: "Entrevista Familiar (Opcional)", 
                          description: "En algunos casos, se coordina una entrevista para conocer las expectativas y presentar el proyecto educativo.", 
                          duration: "1 semana" 
                        },
                        { 
                          step: 4, 
                          title: "Presentación de Documentación y Evaluación Diagnóstica", 
                          description: "Presentación de TODA la documentación requerida y posible prueba de diagnóstico para nivelación.", 
                          duration: "1 semana" 
                        },
                        { 
                          step: 5, 
                          title: "Formalización de la Matrícula", 
                          description: "Firma del Contrato o Reglamento Interno y proceso de matrícula oficial.", 
                          duration: "48 horas hábiles" 
                        },
                        { 
                          step: 6, 
                          title: "Bienvenida Oficial e Inicio de Clases", 
                          description: "¡Bienvenido a la comunidad educativa! Entrega de horarios y calendarios académicos.", 
                          duration: "Inmediato" 
                        }
                      ].map((item, index) => (
                        <div 
                          key={index} 
                          className="flex items-start gap-4 p-3 rounded-xl bg-white/50 hover:bg-white transition-all duration-300 group/step cursor-pointer"
                        >
                          <div className="flex-shrink-0">
                            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-500 text-white rounded-full flex items-center justify-center text-sm font-bold shadow-lg group-hover/step:scale-110 transition-transform duration-300">
                              {item.step}
                            </div>
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between">
                              <h4 className="font-semibold text-slate-800 group-hover/step:text-blue-600 transition-colors duration-300">
                                {item.title}
                              </h4>
                              <span className="text-xs bg-blue-100 text-blue-600 px-2 py-1 rounded-full">
                                {item.duration}
                              </span>
                            </div>
                            <p className="text-sm text-slate-600 mt-1">
                              {item.description}
                            </p>
                          </div>
                          <ArrowRight className="h-4 w-4 text-slate-400 group-hover/step:text-blue-500 group-hover/step:translate-x-1 transition-all duration-300 flex-shrink-0 mt-1" />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>

        </section>

        {/* ===================== NOTICIAS ===================== */}
<section id="noticias" className="py-20 bg-gradient-to-br from-purple-50 to-pink-50" style={{ scrollMarginTop: 120 }}>
  <div className="container mx-auto px-4">
    <div className="max-w-4xl mx-auto text-center mb-16">
      <div className="inline-flex items-center gap-2 px-4 py-2 bg-purple-100 text-purple-700 rounded-full text-sm font-medium mb-4">
        <Megaphone className="h-4 w-4" />
        Novedades
      </div>
      <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-purple-700 to-pink-600 bg-clip-text text-transparent">
        Comunicados y Novedades
      </h2>
      <p className="text-xl text-slate-600 leading-relaxed">
        Información para familias y comunidad educativa.
      </p>
    </div>

    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
      {[
        {
          t: "Celebración del Día de la Madre 2025",
          d: "Nos unimos para celebrar el amor, la dedicación y la ternura de todas las madres en su día.",
          imagen: "/src/assets/fondo4.jpg",
          fecha: "09 Mayo 2025"
        },
        {
          t: "Feria de Ciencia y Tecnología", 
          d: "Participa con tu proyecto STEAM. Inscripciones abiertas.",
          imagen: "/src/assets/fondo5.jpg",
          fecha: "20 Sep 2024"
        },
        {
          t: "Escuela para Padres",
          d: "Talleres sobre hábitos saludables y ciudadanía digital.",
          imagen: "/src/assets/fondo6.jpg",
          fecha: "18 Sep 2024"
        },
      ].map((n, i) => (
        <div key={i} className="group cursor-pointer">
          {/* Tarjeta con efecto hover */}
          <div className="relative h-96 rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500">
            {/* Imagen de fondo */}
            <img
              src={n.imagen}
              alt={n.t}
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
            />
            
            {/* Contenido normal - Badge inferior */}
            <div className="absolute bottom-0 left-0 right-0 p-6 bg-white/90 backdrop-blur-sm transform translate-y-0 group-hover:-translate-y-full opacity-100 group-hover:opacity-0 transition-all duration-500">
              <div className="flex items-start gap-3">
                <div className="bg-purple-600 text-white px-3 py-2 rounded-lg text-center min-w-16">
                  <div className="text-xs font-bold uppercase">MAYO</div>
                  <div className="text-lg font-bold">09</div>
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-bold text-slate-800 mb-1 line-clamp-2">
                    {n.t}
                  </h3>
                  <Button variant="ghost" size="sm" className="text-purple-600 hover:text-purple-700 p-0 h-auto font-semibold">
                    Ver más...
                  </Button>
                </div>
              </div>
            </div>

            {/* Overlay que aparece al hover - Se despliega desde abajo hacia arriba */}
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-blue/40 to-transparent opacity-0 group-hover:opacity-100 transition-all duration-500">
              <div className="absolute bottom-0 left-0 right-0 p-6 text-white transform translate-y-full group-hover:translate-y-0 transition-transform duration-500">
                <div className="mb-3">
                  <span className="text-sm text-white/80 bg-white/20 backdrop-blur-sm px-3 py-1 rounded-full">
                    {n.fecha}
                  </span>
                </div>
                <h3 className="text-2xl font-bold mb-3">
                  {n.t}
                </h3>
                <p className="text-white/90 leading-relaxed mb-4">
                  {n.d}
                </p>
                <Button className="bg-white/20 hover:bg-white/30 text-white border-white/30 hover:border-white/50 backdrop-blur-sm transition-all duration-300 group/btn">
                  <span>Ver más...</span>
                  <ArrowRight className="h-4 w-4 ml-2 group-hover/btn:translate-x-1 transition-transform duration-300" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>

    {/* Botón para ver más noticias */}
    <div className="text-center mt-12">
      <Button className="bg-purple-600 hover:bg-purple-700 text-white rounded-xl px-8 py-6 transition-all duration-300 group">
        <span className="mr-2">Ver todas las noticias</span>
        <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform duration-300" />
      </Button>
    </div>
  </div>


</section>

        {/* ===================== CONTACTO ===================== */}
        <section id="contact" className="py-20 bg-white" style={{ scrollMarginTop: 120 }}>
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto text-center mb-16">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-medium mb-4">
                <Mail className="h-4 w-4" />
                Contáctanos
              </div>
              <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-to-r from-slate-800 to-slate-600 bg-clip-text text-transparent">
                Hablemos
              </h2>
              <p className="text-xl text-slate-600 leading-relaxed">
                Escríbenos y con gusto te respondemos.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-6xl mx-auto">
              <Card className="border-0 shadow-xl rounded-2xl">
                <CardHeader>
                  <CardTitle className="text-xl font-bold text-slate-800">Envíanos un Mensaje</CardTitle>
                </CardHeader>
                <CardContent>
                  <form className="space-y-4" onSubmit={handleContacto}>
                    <Input
                      placeholder="Nombre y Apellidos"
                      value={ctNombre}
                      onChange={(e) => setCtNombre(e.target.value)}
                      className="rounded-xl py-3"
                    />
                    <Input
                      placeholder="Correo electrónico"
                      type="email"
                      value={ctCorreo}
                      onChange={(e) => setCtCorreo(e.target.value)}
                      className="rounded-xl py-3"
                    />
                    <Textarea
                      placeholder="Tu mensaje"
                      value={ctMensaje}
                      onChange={(e) => setCtMensaje(e.target.value)}
                      className="rounded-xl min-h-[120px]"
                    />
                    <div className="flex gap-3">
                      <Button type="submit" className="rounded-xl flex-1 bg-blue-600 hover:bg-blue-700">
                        Enviar Mensaje
                      </Button>
                      <a href="mailto:contacto@uepth.edu.pe">
                        <Button type="button" variant="outline" className="rounded-xl">
                          Abrir Correo
                        </Button>
                      </a>
                    </div>
                  </form>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-xl bg-gradient-to-br from-slate-50 to-blue-50 rounded-2xl">
                <CardContent className="p-8 space-y-6">
                  <h3 className="text-xl font-bold text-slate-800">Información de Contacto</h3>
                  <div className="space-y-4">
                    <div className="flex items-center gap-3 text-slate-700">
                      <div className="p-2 bg-white rounded-xl shadow-sm">
                        <MapPin className="h-5 w-5 text-blue-600" />
                      </div>
                      <span>Av. Educación 123, Bolivia</span>
                    </div>
                    <div className="flex items-center gap-3 text-slate-700">
                      <div className="p-2 bg-white rounded-xl shadow-sm">
                        <Phone className="h-5 w-5 text-blue-600" />
                      </div>
                      <a className="hover:text-blue-600 hover:underline transition-colors" href="tel:+51900000000">
                        + 900 000 000
                      </a>
                    </div>
                    <div className="flex items-center gap-3 text-slate-700">
                      <div className="p-2 bg-white rounded-xl shadow-sm">
                        <Mail className="h-5 w-5 text-blue-600" />
                      </div>
                      <a className="hover:text-blue-600 hover:underline transition-colors" href="mailto:contacto@uepth.edu.pe">
                        contacto@uepth.edu
                      </a>
                    </div>
                    <div className="flex items-center gap-3 text-slate-700">
                      <div className="p-2 bg-white rounded-xl shadow-sm">
                        <CalendarDays className="h-5 w-5 text-blue-600" />
                      </div>
                      <span>Atención: Lun–Vie 07:30 – 15:30</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>

        {/* ===================== SOPORTE ===================== */}
        <section id="support" className="py-16 bg-gradient-to-r from-blue-600 to-purple-700 text-white">
          <div className="container mx-auto px-4">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6 max-w-6xl mx-auto">
              <div className="text-center md:text-left">
                <h3 className="text-2xl font-bold mb-2">¿Necesitas Ayuda?</h3>
                <p className="text-blue-100 text-lg">
                  Visita nuestro centro de soporte o escríbenos.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <a href="#about">
                  <Button variant="secondary" className="rounded-xl bg-white text-blue-700 hover:bg-blue-50">
                    Manual de Usuario
                  </Button>
                </a>
                <a href="#contact">
                  <Button variant="outline" className="rounded-xl border-white text-white hover:bg-white/10">
                    Contactar Soporte
                  </Button>
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default Index;
