// src/pages/ParentDashboard.tsx
import { useState } from "react";
import { useNavigate, Outlet, useLocation } from "react-router-dom";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, BookOpen, User, TrendingUp, Calendar, FileText, Star, CheckCircle } from "lucide-react";

const ParentDashboard = () => {
  const [selectedStudent] = useState("Juan Pérez Martínez");
  const navigate = useNavigate();
  const location = useLocation();

  // 🔹 Sidebar personalizado para padres
  const sidebarContent = (
    <div className="space-y-2">
      <Button
        variant="ghost"
        className="w-full justify-start"
        onClick={() => navigate("/dashboard/parent/informacion-estudiante")}
      >
        <User className="h-4 w-4 mr-2" /> Información del Estudiante
      </Button>

      <Button
        variant="ghost"
        className="w-full justify-start"
        onClick={() => navigate("/dashboard/parent/notas-academicas")}
      >
        <BookOpen className="h-4 w-4 mr-2" /> Notas Académicas
      </Button>

      <Button
        variant="ghost"
        className="w-full justify-start"
        onClick={() => navigate("/dashboard/parent/conducta")}
      >
        <Star className="h-4 w-4 mr-2" /> Conducta
      </Button>

      <Button
        variant="ghost"
        className="w-full justify-start"
        onClick={() => navigate("/dashboard/parent/tareas")}
      >
        <Calendar className="h-4 w-4 mr-2" /> Tareas
      </Button>

      <Button
        variant="ghost"
        className="w-full justify-start"
        onClick={() => navigate("/dashboard/parent/progreso")}
      >
        <TrendingUp className="h-4 w-4 mr-2" /> Progreso
      </Button>

      <Button
        variant="ghost"
        className="w-full justify-start"
        onClick={() => navigate("/dashboard/parent/reportes")}
      >
        <FileText className="h-4 w-4 mr-2" /> Reportes
      </Button>

      {/* ➕ NUEVO: botón Asistencia (padres) */}
      <Button
        variant="ghost"
        className="w-full justify-start"
        onClick={() => navigate("/dashboard/parent/asistencia")}
      >
        <CheckCircle className="h-4 w-4 mr-2" /> Asistencia
      </Button>
      <Button
        variant="ghost"
        className="w-full justify-start"
        onClick={() => navigate("/dashboard/parent/logrosparents")}
      >
        <CheckCircle className="h-4 w-4 mr-2" /> Logros
      </Button>
    </div>
  );

  return (
    <DashboardLayout
      userType="parent"
      userName="María González"
      userInfo="Madre de Juan Pérez"
      sidebarContent={sidebarContent}
    >
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">Panel de Padres</h1>
            <p className="text-muted-foreground">
              Seguimiento académico de:{" "}
              <span className="font-semibold text-foreground">{selectedStudent}</span>
            </p>
          </div>
          <Button variant="academicYellow" onClick={() => alert("Generando reporte PDF…")}>
            <Download className="h-4 w-4 mr-2" />
            Generar Reporte
          </Button>
        </div>

        {/* Outlet para páginas internas */}
        <Outlet />

        {/* Si estamos exactamente en /dashboard/parent (sin subruta), mostramos bienvenida */}
        {location.pathname === "/dashboard/parent" && (
          <Card>
            <CardHeader>
              <CardTitle>Bienvenida</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Usa el menú lateral para navegar por la información de tu hijo.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
};

export default ParentDashboard;
