// src/pages/StudentDashboard.tsx
import { useNavigate, Outlet, useLocation } from "react-router-dom";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  BookOpen,
  ClipboardList,
  FileText,
  CalendarCheck,
  Clock,
  TrendingUp,
  Download
} from "lucide-react";

const StudentDashboard = () => {
  const navigate = useNavigate();
  const location = useLocation();

  // 🔹 Sidebar personalizado para estudiantes
  const sidebarContent = (
    <div className="space-y-2">
      <Button
        variant="ghost"
        className="w-full justify-start"
        onClick={() => navigate("/dashboard/student/informacion")}
      >
        <BookOpen className="h-4 w-4 mr-2" /> Mi Informacion
      </Button>
      <Button
        variant="ghost"
        className="w-full justify-start"
        onClick={() => navigate("/dashboard/student/materias")}
      >
        <BookOpen className="h-4 w-4 mr-2" /> Mis Materias
      </Button>
      <Button
        variant="ghost"
        className="w-full justify-start"
        onClick={() => navigate("/dashboard/student/tareas")}
      >
        <ClipboardList className="h-4 w-4 mr-2" /> Mis Tareas
      </Button>
      <Button
        variant="ghost"
        className="w-full justify-start"
        onClick={() => navigate("/dashboard/student/notas")}
      >
        <FileText className="h-4 w-4 mr-2" /> Mis Notas
      </Button>
      <Button
        variant="ghost"
        className="w-full justify-start"
        onClick={() => navigate("/dashboard/student/asistencia")}
      >
        <CalendarCheck className="h-4 w-4 mr-2" /> Mi Asistencia
      </Button>
      <Button
        variant="ghost"
        className="w-full justify-start"
        onClick={() => navigate("/dashboard/student/horario")}
      >
        <Clock className="h-4 w-4 mr-2" /> Mi Horario
      </Button>
      <Button
        variant="ghost"
        className="w-full justify-start"
        onClick={() => navigate("/dashboard/student/progreso")}
      >
        <TrendingUp className="h-4 w-4 mr-2" /> Mi Progreso
      </Button>
    </div>
  );

  return (
    <DashboardLayout
      userType="student"
      userName="Carlos Ramírez"
      userInfo="Estudiante de 5to Secundaria"
      sidebarContent={sidebarContent}
    >
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-foreground mb-2">
              Panel del Estudiante
            </h1>
            <p className="text-muted-foreground">
              Bienvenido al sistema académico, revisa tus materias, tareas y
              progreso.
            </p>
          </div>
          <Button variant="academicYellow">
            <Download className="h-4 w-4 mr-2" />
            Descargar Reporte
          </Button>
        </div>

        {/* Outlet para subpáginas */}
        <Outlet />

        {/* Si estamos exactamente en /dashboard/student mostramos bienvenida */}
        {location.pathname === "/dashboard/student" && (
          <Card>
            <CardHeader>
              <CardTitle>Bienvenido</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Usa el menú lateral para acceder a tus materias, tareas, notas y
                demás información académica.
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </DashboardLayout>
  );
};

export default StudentDashboard;
